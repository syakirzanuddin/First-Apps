package com.example.twmobileapptest_syakir;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class HelperAdapter extends RecyclerView.Adapter.<HelperAdapter.MyViewClass> {


    public class MyViewClass extends RecyclerView.ViewHolder {

        TextView firstName;
        TextView lastName;
        TextView email;
        TextView phone;

        public MyViewClass(@NonNull View itemView){
            super(itemView);

            firstName = (TextView) itemView.findViewById(R.id.firstName);
            lastName = (TextView) itemView.findViewById(R.id.lastName);
            email = (TextView) itemView.findViewById(R.id.email);
            phone = (TextView) itemView.findViewById(R.id.phone);

        }
    }
}
