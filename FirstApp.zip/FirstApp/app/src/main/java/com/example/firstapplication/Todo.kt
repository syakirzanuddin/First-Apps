package com.example.firstapplication

data class Todo(
        val title: String,
        var isChecked: Boolean
)

